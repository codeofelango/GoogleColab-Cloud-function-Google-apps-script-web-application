import numpy as np
import pandas as pd
import os
import pickle
from google.cloud import storage
from models import *

## Gloabl model variable
model = None
transmodel = None


# Main entry point for the cloud function
def sentimentanalysis(request):   
    global transmodel
    if not transmodel:
        download_tranformmodel()
        transmodel = pickle.load(open("/tmp/transtemp_model.pkl", 'rb'))

        # Use the global model variable 
    global model
    if not model:
        download_nlpmodel()
        model = pickle.load(open("/tmp/nlptemp_model.pkl", 'rb'))

    data = request.get_json()
    user_query = data.get('query')    
    # user_query = request.json['query']
    print(user_query)
    if user_query == None or user_query == '' :
        return "Message needed to predict"
        # vectorize the user's query and make a prediction
    try:    
        print('start here')
        print(np.array([user_query]))
        vectorized = transmodel.transform(np.array([user_query]))
        print(vectorized)
        prediction = model.predict(vectorized)
        print(prediction)
        if prediction == 0:
            pred_text = 'Negative'
        else:
            pred_text = 'Positive' 
                    
        output = {'prediction': pred_text}
        return output   
    except Exception as e:
        return "Bad Request"          
