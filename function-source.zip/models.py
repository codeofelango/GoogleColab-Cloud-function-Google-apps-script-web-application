import numpy as np
import pandas as pd
import os
import pickle
from google.cloud import storage

# Download model file from cloud storage bucket
def download_nlpmodel():
    # Model Bucket details
    BUCKET_NAME        = "mlsys"
    PROJECT_ID         = "atlantean-talon-162113"
    GCS_MODEL_FILE     = "nlp_model.pkl"

    # Initialise a client
    client   = storage.Client(PROJECT_ID)
    
    # Create a bucket object for our bucket
    bucket   = client.get_bucket(BUCKET_NAME)
    
    # Create a blob object from the filepath
    blob     = bucket.blob(GCS_MODEL_FILE)
    
    folder = '/tmp/'
    if not os.path.exists(folder):
      os.makedirs(folder)
    # Download the file to a destination
    blob.download_to_filename(folder + "nlptemp_model.pkl")


# Download model file from cloud storage bucket
def download_tranformmodel():
    # Model Bucket details
    BUCKET_NAME        = "mlsys"
    PROJECT_ID         = "atlantean-talon-162113"
    GCS_MODEL_FILE     = "tranform.pkl"

    # Initialise a client
    client   = storage.Client(PROJECT_ID)
    
    # Create a bucket object for our bucket
    bucket   = client.get_bucket(BUCKET_NAME)
    
    # Create a blob object from the filepath
    blob     = bucket.blob(GCS_MODEL_FILE)
    
    folder = '/tmp/'
    if not os.path.exists(folder):
      os.makedirs(folder)
    # Download the file to a destination
    blob.download_to_filename(folder + "transtemp_model.pkl")
